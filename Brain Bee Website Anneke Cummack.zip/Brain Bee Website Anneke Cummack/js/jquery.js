//each one of these sections makes the audio play when the mouse hovers over the 'trigger word'
function playclip1() { 
    //name of the function (linking it to its name in the html)
var audio = document.getElementById("myelin-sheath"); audio.play(); 
    //name of the audio tag, links the trigger and audio together
}

//code must be repeated for each audio file

function playclip2() {
var audio = document.getElementById("glutamate"); audio.play(); 
}

function playclip3() {
var audio = document.getElementById("acetylcholine"); audio.play(); 
}

function playclip4() {
var audio = document.getElementById("dopamine"); audio.play(); 
}

function playclip5() {
var audio = document.getElementById("norepinephrine"); audio.play(); 
}

function playclip6() {
var audio = document.getElementById("ionotropic"); audio.play(); 
}

function playclip7() {
var audio = document.getElementById("metabotropic"); audio.play(); 
}